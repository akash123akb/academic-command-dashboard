---
name: Academic Command Center
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e18'
  surface-container-low: '#171b26'
  surface-container: '#1c1f2a'
  surface-container-high: '#262a35'
  surface-container-highest: '#313540'
  on-surface: '#dfe2f1'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#dfe2f1'
  inverse-on-surface: '#2c303b'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#d0bcff'
  on-secondary: '#3c0091'
  secondary-container: '#571bc1'
  on-secondary-container: '#c4abff'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#00a572'
  on-tertiary-container: '#00311f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d0bcff'
  on-secondary-fixed: '#23005c'
  on-secondary-fixed-variant: '#5516be'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#0f131d'
  on-background: '#dfe2f1'
  surface-variant: '#313540'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.005em
  label-code-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
  label-code-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0em
  label-code-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an ultra-focused, mission-critical workspace engineered for undergraduate engineering students navigating rigorous technical curricula. The atmosphere evokes the precision, control, and density of high-performance developer environments, cloud infrastructure dashboards, and aerospace telemetry consoles—tailored specifically to academic mastery.

### Personality & Emotional Tenor
- **Analytical & Authoritative:** Instills confidence through structured visual hierarchy, real-time tracking, and deterministic data presentation.
- **Cognitive Clarity:** Eliminates visual noise; uses micro-contrast and luminance layering to sustain deep focus during marathon study and lab sessions.
- **Electric Precision:** Accentuated with luminous spectral highlights that make academic milestones, syllabus velocity, and deadlines feel dynamic and consequential.

### Design Movement
The visual language merges **Technical Modern SaaS** with **Tactile Cybernetic Glass**. It leverages deep obsidian and navy foundations, razor-sharp 1px micro-borders (`rgba(255, 255, 255, 0.08)`), subtle neon back-glows, semi-translucent frosted telemetry chips, and high-density information widgets optimized for rapid scanning on mobile and desktop viewports.

## Colors

The palette relies on absolute darkness punctuated by disciplined, emission-like accents. Surfaces do not rely on standard grays; instead, they utilize deep navy-charcoal tiers that preserve eye comfort in low-light laboratory and study settings.

### Surface Architecture
- **Base Canvas (`#0B0F19`):** The master substrate. Absorbs ambient light and grounds high-contrast data.
- **Surface Layer 1 (`#111827`):** Primary card and panel backgrounds.
- **Surface Layer 2 (`#1F2937`):** Elevated modules, nested containers, dropdowns, and active states.
- **Surface Glass (`rgba(17, 24, 39, 0.72)`): Frosted panels with `backdrop-filter: blur(16px)`.

### Chromatic Roles
- **Electric Blue (`#3B82F6`):** The primary signal. Drives main calls to action, active navigation tabs, interactive links, and forward momentum.
- **Luminous Violet (`#8B5CF6`):** The secondary signal. Designates advanced modules, MAKAUT module completions, algorithms, and core engineering tracks.
- **Emerald Telemetry (`#10B981`):** Tertiary indicator for passing grades, verified lab submissions, syllabus completion, and optimal attendance metrics.
- **Amber Warning (`#F59E0B`):** Critical alerting for CA (Continuous Assessment) deadlines, impending exam dates, and low-attendance thresholds (<75%).
- **Micro-Border Accent (`rgba(255, 255, 255, 0.08)`): Ubiquitous architectural separator providing edge definition across all cards.

## Typography

The typographic architecture balances human-scale interface legibility with technical metadata rigor through a strict dual-font strategy.

- **Primary UI & Headings (Inter):** Handles user interface copy, navigation, module titles, and body content. Selected for its neutral tone, tall x-height, and exceptional rendering clarity on high-DPI screens.
- **Technical & Telemetry (JetBrains Mono):** Dedicated to course codes (e.g., `PCC-CS301`, `ESC-301`), grade points, semester GPAs, timers, timestamps, attendance rates, and code snippets. Conveys engineering authority and guarantees strict tabular numeric alignment across mobile data cards.

## Layout & Spacing

The layout operates on an 8-point rhythmic grid with a 4-point micro-subgrid for dense technical dashboards.

### Grid Framework
- **Mobile (< 768px):** Single-column stack with `margin: 1rem` and `gutter: 1rem`. High-priority telemetry counters form horizontal swipe strips or 2-column micro-grids.
- **Tablet (768px – 1024px):** 6-column fluid grid, adapting side-by-side modules for course trackers and lab assessment calendars.
- **Desktop (> 1024px):** 12-column asymmetric command deck with a permanent 280px left rail for curriculum indexing, an 8-column primary focus canvas, and a 4-column contextual telemetry sidebar.

### Micro-Density Philosophy
Data cards avoid excessive empty margins. Internal component padding scales between `space-sm` (8px) and `space-md` (16px) on mobile viewports to surface critical MAKAUT syllabus matrices without demanding excessive vertical scrolling.

## Elevation & Depth

This system rejects physical drop shadows in favor of **luminance layering**, **micro-borders**, and **chromatic ambient glows**.

### Layering Hierarchy
1. **Canvas (`#0B0F19`):** Deep ground layer.
2. **Base Panels (`#111827`):** Elevated via `border: 1px solid rgba(255, 255, 255, 0.08)`.
3. **Interactive & Floating Cards (`#1F2937` / Glass):** Backdropped with `blur(16px)` and illuminated with edge light.
4. **Active Neon Aura:** High-priority items (such as urgent CA submissions or exam counters) project a diffused, colored radial glow:
   - Primary Focus: `box-shadow: 0 0 24px -4px rgba(59, 130, 246, 0.25)`
   - Warning Alert: `box-shadow: 0 0 24px -4px rgba(245, 158, 11, 0.2)`
   - Success Status: `box-shadow: 0 0 24px -4px rgba(16, 185, 129, 0.2)`

## Shapes

The design uses a refined, modern curvature system that softens technical data without looking playful or childish.

- **Base Radius (`0.5rem` / 8px):** Used for micro-badges, inline code tags, buttons, and input fields.
- **Container Radius (`1rem` / 16px):** Standard card curvature across academic telemetry cards, subject modules, and modals.
- **Feature Radius (`1.5rem` / 24px):** Outer frame for master panels, command palettes, and floating bottom sheets on mobile.

## Components

### Buttons
- **Primary Action:** Solid electric blue (`#3B82F6`) fill, text in pure white, font weight 600. Features a subtle inner top highlight (`inset 0 1px 0 rgba(255, 255, 255, 0.2)`) and an active scale down to `0.98`.
- **Secondary Ghost:** Surface background (`rgba(255, 255, 255, 0.04)`), crisp 1px border (`rgba(255, 255, 255, 0.08)`), text `#E5E7EB`. On hover, the border brightens to `rgba(59, 130, 246, 0.4)`.

### Telemetry Badges & Chips
- Rendered in `JetBrains Mono` (`label-code-sm`).
- Glassmorphic translucent surfaces: `background: rgba(primary/secondary/tertiary, 0.12)`, `border: 1px solid rgba(primary/secondary/tertiary, 0.3)`.
- Pill or 6px micro-rounded structures used for subject codes (`CS301`), credits (`4.0 CR`), and exam status indicators.

### Cards & Modules
- Structured on `#111827` with 1px border (`rgba(255, 255, 255, 0.08)`).
- Card headers incorporate an icon container with a subtle violet or electric-blue glow, paired with a right-aligned tabular telemetry metric (e.g., attendance percentage or syllabus progress bar).

### Inputs & Selectors
- Background: `#0B0F19`.
- Border: `1px solid rgba(255, 255, 255, 0.12)`.
- Focus state: Border shifts to `#3B82F6` accompanied by an electric halo (`0 0 0 3px rgba(59, 130, 246, 0.2)`).

### Academic Progress Indicators
- Linear progress tracks: `#1F2937` with an electric blue or emerald gradient fill.
- Radial circular gauges: High-contrast strokes displaying MAKAUT MAR/MOOCs point accrual and attendance thresholds with numeric centers set in `JetBrains Mono`.